#!/bin/bash

cp params_01 params_02
cp params_01 params_03
cp params_01 params_04
cp params_01 params_05
cp params_01 params_06
cp params_01 params_07
cp params_01 params_08
cp params_01 params_09
cp params_01 params_10
cp params_01 params_11
cp params_01 params_12
cp params_01 params_13
cp params_01 params_14
cp params_01 params_15
cp params_01 params_16
cp params_01 params_17
cp params_01 params_18
cp params_01 params_19
cp params_01 params_20
cp params_01 params_21
cp params_01 params_22
cp params_01 params_23
cp params_01 params_24
cp params_01 params_25
cp params_01 params_26
cp params_01 params_27
cp params_01 params_28
cp params_01 params_29
cp params_01 params_30
cp params_01 params_31
cp params_01 params_32
cp params_01 params_33
cp params_01 params_34
cp params_01 params_35
cp params_01 params_36
cp params_01 params_37
cp params_01 params_38
cp params_01 params_39
cp params_01 params_40
cp params_01 params_41
cp params_01 params_42
cp params_01 params_43
cp params_01 params_44
cp params_01 params_45
cp params_01 params_46
cp params_01 params_47
cp params_01 params_48
cp params_01 params_49
cp params_01 params_50
cp params_01 params_51
cp params_01 params_52
cp params_01 params_53
cp params_01 params_54
cp params_01 params_55
cp params_01 params_56
cp params_01 params_57
cp params_01 params_58
cp params_01 params_59
cp params_01 params_60
cp params_01 params_61
cp params_01 params_62
cp params_01 params_63
cp params_01 params_64
cp params_01 params_65
cp params_01 params_66
cp params_01 params_67
cp params_01 params_68
cp params_01 params_69
cp params_01 params_70

perl -i -p -e '$_=~s/1		! nmax/2		! nmax/g' params_02
perl -i -p -e '$_=~s/1		! nmax/3		! nmax/g' params_03
perl -i -p -e '$_=~s/1		! nmax/4		! nmax/g' params_04
perl -i -p -e '$_=~s/1		! nmax/5		! nmax/g' params_05
perl -i -p -e '$_=~s/1		! nmax/6		! nmax/g' params_06
perl -i -p -e '$_=~s/1		! nmax/7		! nmax/g' params_07
perl -i -p -e '$_=~s/1		! nmax/8		! nmax/g' params_08
perl -i -p -e '$_=~s/1		! nmax/9		! nmax/g' params_09
perl -i -p -e '$_=~s/1		! nmax/10		! nmax/g' params_10
perl -i -p -e '$_=~s/1		! nmax/11		! nmax/g' params_11
perl -i -p -e '$_=~s/1		! nmax/12		! nmax/g' params_12
perl -i -p -e '$_=~s/1		! nmax/13		! nmax/g' params_13
perl -i -p -e '$_=~s/1		! nmax/14		! nmax/g' params_14
perl -i -p -e '$_=~s/1		! nmax/15		! nmax/g' params_15
perl -i -p -e '$_=~s/1		! nmax/16		! nmax/g' params_16
perl -i -p -e '$_=~s/1		! nmax/17		! nmax/g' params_17
perl -i -p -e '$_=~s/1		! nmax/18		! nmax/g' params_18
perl -i -p -e '$_=~s/1		! nmax/19		! nmax/g' params_19
perl -i -p -e '$_=~s/1		! nmax/29		! nmax/g' params_29
perl -i -p -e '$_=~s/1		! nmax/20		! nmax/g' params_20
perl -i -p -e '$_=~s/1		! nmax/21		! nmax/g' params_21
perl -i -p -e '$_=~s/1		! nmax/22		! nmax/g' params_22
perl -i -p -e '$_=~s/1		! nmax/23		! nmax/g' params_23
perl -i -p -e '$_=~s/1		! nmax/24		! nmax/g' params_24
perl -i -p -e '$_=~s/1		! nmax/25		! nmax/g' params_25
perl -i -p -e '$_=~s/1		! nmax/26		! nmax/g' params_26
perl -i -p -e '$_=~s/1		! nmax/27		! nmax/g' params_27
perl -i -p -e '$_=~s/1		! nmax/28		! nmax/g' params_28
perl -i -p -e '$_=~s/1		! nmax/29		! nmax/g' params_29
perl -i -p -e '$_=~s/1		! nmax/30		! nmax/g' params_30
perl -i -p -e '$_=~s/1		! nmax/31		! nmax/g' params_31
perl -i -p -e '$_=~s/1		! nmax/32		! nmax/g' params_32
perl -i -p -e '$_=~s/1		! nmax/33		! nmax/g' params_33
perl -i -p -e '$_=~s/1		! nmax/34		! nmax/g' params_34
perl -i -p -e '$_=~s/1		! nmax/35		! nmax/g' params_35
perl -i -p -e '$_=~s/1		! nmax/36		! nmax/g' params_36
perl -i -p -e '$_=~s/1		! nmax/37		! nmax/g' params_37
perl -i -p -e '$_=~s/1		! nmax/38		! nmax/g' params_38
perl -i -p -e '$_=~s/1		! nmax/39		! nmax/g' params_39
perl -i -p -e '$_=~s/1		! nmax/40		! nmax/g' params_40
perl -i -p -e '$_=~s/1		! nmax/41		! nmax/g' params_41
perl -i -p -e '$_=~s/1		! nmax/42		! nmax/g' params_42
perl -i -p -e '$_=~s/1		! nmax/43		! nmax/g' params_43
perl -i -p -e '$_=~s/1		! nmax/44		! nmax/g' params_44
perl -i -p -e '$_=~s/1		! nmax/45		! nmax/g' params_45
perl -i -p -e '$_=~s/1		! nmax/46		! nmax/g' params_46
perl -i -p -e '$_=~s/1		! nmax/47		! nmax/g' params_47
perl -i -p -e '$_=~s/1		! nmax/48		! nmax/g' params_48
perl -i -p -e '$_=~s/1		! nmax/49		! nmax/g' params_49
perl -i -p -e '$_=~s/1		! nmax/50		! nmax/g' params_50
perl -i -p -e '$_=~s/1		! nmax/51		! nmax/g' params_51
perl -i -p -e '$_=~s/1		! nmax/52		! nmax/g' params_52
perl -i -p -e '$_=~s/1		! nmax/53		! nmax/g' params_53
perl -i -p -e '$_=~s/1		! nmax/54		! nmax/g' params_54
perl -i -p -e '$_=~s/1		! nmax/55		! nmax/g' params_55
perl -i -p -e '$_=~s/1		! nmax/56		! nmax/g' params_56
perl -i -p -e '$_=~s/1		! nmax/57		! nmax/g' params_57
perl -i -p -e '$_=~s/1		! nmax/58		! nmax/g' params_58
perl -i -p -e '$_=~s/1		! nmax/59		! nmax/g' params_59
perl -i -p -e '$_=~s/1		! nmax/60		! nmax/g' params_60
perl -i -p -e '$_=~s/1		! nmax/61		! nmax/g' params_61
perl -i -p -e '$_=~s/1		! nmax/62		! nmax/g' params_62
perl -i -p -e '$_=~s/1		! nmax/63		! nmax/g' params_63
perl -i -p -e '$_=~s/1		! nmax/64		! nmax/g' params_64
perl -i -p -e '$_=~s/1		! nmax/65		! nmax/g' params_65
perl -i -p -e '$_=~s/1		! nmax/66		! nmax/g' params_66
perl -i -p -e '$_=~s/1		! nmax/67		! nmax/g' params_67
perl -i -p -e '$_=~s/1		! nmax/68		! nmax/g' params_68
perl -i -p -e '$_=~s/1		! nmax/69		! nmax/g' params_69
perl -i -p -e '$_=~s/1		! nmax/70		! nmax/g' params_70


perl -i -p -e '$_=~s/1		! mmax/2		! mmax/g' params_02
perl -i -p -e '$_=~s/1		! mmax/3		! mmax/g' params_03
perl -i -p -e '$_=~s/1		! mmax/4		! mmax/g' params_04
perl -i -p -e '$_=~s/1		! mmax/5		! mmax/g' params_05
perl -i -p -e '$_=~s/1		! mmax/6		! mmax/g' params_06
perl -i -p -e '$_=~s/1		! mmax/7		! mmax/g' params_07
perl -i -p -e '$_=~s/1		! mmax/8		! mmax/g' params_08
perl -i -p -e '$_=~s/1		! mmax/9		! mmax/g' params_09
perl -i -p -e '$_=~s/1		! mmax/10		! mmax/g' params_10
perl -i -p -e '$_=~s/1		! mmax/11		! mmax/g' params_11
perl -i -p -e '$_=~s/1		! mmax/12		! mmax/g' params_12
perl -i -p -e '$_=~s/1		! mmax/13		! mmax/g' params_13
perl -i -p -e '$_=~s/1		! mmax/14		! mmax/g' params_14
perl -i -p -e '$_=~s/1		! mmax/15		! mmax/g' params_15
perl -i -p -e '$_=~s/1		! mmax/16		! mmax/g' params_16
perl -i -p -e '$_=~s/1		! mmax/17		! mmax/g' params_17
perl -i -p -e '$_=~s/1		! mmax/18		! mmax/g' params_18
perl -i -p -e '$_=~s/1		! mmax/19		! mmax/g' params_19
perl -i -p -e '$_=~s/1		! mmax/29		! mmax/g' params_29
perl -i -p -e '$_=~s/1		! mmax/20		! mmax/g' params_20
perl -i -p -e '$_=~s/1		! mmax/21		! mmax/g' params_21
perl -i -p -e '$_=~s/1		! mmax/22		! mmax/g' params_22
perl -i -p -e '$_=~s/1		! mmax/23		! mmax/g' params_23
perl -i -p -e '$_=~s/1		! mmax/24		! mmax/g' params_24
perl -i -p -e '$_=~s/1		! mmax/25		! mmax/g' params_25
perl -i -p -e '$_=~s/1		! mmax/26		! mmax/g' params_26
perl -i -p -e '$_=~s/1		! mmax/27		! mmax/g' params_27
perl -i -p -e '$_=~s/1		! mmax/28		! mmax/g' params_28
perl -i -p -e '$_=~s/1		! mmax/29		! mmax/g' params_29
perl -i -p -e '$_=~s/1		! mmax/30		! mmax/g' params_30
perl -i -p -e '$_=~s/1		! mmax/31		! mmax/g' params_31
perl -i -p -e '$_=~s/1		! mmax/32		! mmax/g' params_32
perl -i -p -e '$_=~s/1		! mmax/33		! mmax/g' params_33
perl -i -p -e '$_=~s/1		! mmax/34		! mmax/g' params_34
perl -i -p -e '$_=~s/1		! mmax/35		! mmax/g' params_35
perl -i -p -e '$_=~s/1		! mmax/36		! mmax/g' params_36
perl -i -p -e '$_=~s/1		! mmax/37		! mmax/g' params_37
perl -i -p -e '$_=~s/1		! mmax/38		! mmax/g' params_38
perl -i -p -e '$_=~s/1		! mmax/39		! mmax/g' params_39
perl -i -p -e '$_=~s/1		! mmax/40		! mmax/g' params_40
perl -i -p -e '$_=~s/1		! mmax/41		! mmax/g' params_41
perl -i -p -e '$_=~s/1		! mmax/42		! mmax/g' params_42
perl -i -p -e '$_=~s/1		! mmax/43		! mmax/g' params_43
perl -i -p -e '$_=~s/1		! mmax/44		! mmax/g' params_44
perl -i -p -e '$_=~s/1		! mmax/45		! mmax/g' params_45
perl -i -p -e '$_=~s/1		! mmax/46		! mmax/g' params_46
perl -i -p -e '$_=~s/1		! mmax/47		! mmax/g' params_47
perl -i -p -e '$_=~s/1		! mmax/48		! mmax/g' params_48
perl -i -p -e '$_=~s/1		! mmax/49		! mmax/g' params_49
perl -i -p -e '$_=~s/1		! mmax/50		! mmax/g' params_50
perl -i -p -e '$_=~s/1		! mmax/51		! mmax/g' params_51
perl -i -p -e '$_=~s/1		! mmax/52		! mmax/g' params_52
perl -i -p -e '$_=~s/1		! mmax/53		! mmax/g' params_53
perl -i -p -e '$_=~s/1		! mmax/54		! mmax/g' params_54
perl -i -p -e '$_=~s/1		! mmax/55		! mmax/g' params_55
perl -i -p -e '$_=~s/1		! mmax/56		! mmax/g' params_56
perl -i -p -e '$_=~s/1		! mmax/57		! mmax/g' params_57
perl -i -p -e '$_=~s/1		! mmax/58		! mmax/g' params_58
perl -i -p -e '$_=~s/1		! mmax/59		! mmax/g' params_59
perl -i -p -e '$_=~s/1		! mmax/60		! mmax/g' params_60
perl -i -p -e '$_=~s/1		! mmax/61		! mmax/g' params_61
perl -i -p -e '$_=~s/1		! mmax/62		! mmax/g' params_62
perl -i -p -e '$_=~s/1		! mmax/63		! mmax/g' params_63
perl -i -p -e '$_=~s/1		! mmax/64		! mmax/g' params_64
perl -i -p -e '$_=~s/1		! mmax/65		! mmax/g' params_65
perl -i -p -e '$_=~s/1		! mmax/66		! mmax/g' params_66
perl -i -p -e '$_=~s/1		! mmax/67		! mmax/g' params_67
perl -i -p -e '$_=~s/1		! mmax/68		! mmax/g' params_68
perl -i -p -e '$_=~s/1		! mmax/69		! mmax/g' params_69
perl -i -p -e '$_=~s/1		! mmax/70		! mmax/g' params_70









