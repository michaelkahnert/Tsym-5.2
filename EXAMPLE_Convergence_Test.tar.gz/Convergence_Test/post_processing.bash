#!/bin/bash


base=output

#=========================================================
#  Collect cross section for different nmax in one file:
#=========================================================
cd $base
#----------------------------------
#  first orientation:
#----------------------------------
files=`ls C000001_??`
outfile=OP1
if [ -f $outfile ]; then
    rm $outfile
fi
touch $outfile


for infile in $files; do
    suffx=${infile:8}
    cext=`head -1 $infile |tail -1 | cut -c 1-18`
    csca=`head -2 $infile |tail -1 | cut -c 1-18`
    cabs=`head -3 $infile |tail -1 | cut -c 1-18`
    qext=`head -4 $infile |tail -1 | cut -c 1-18`
    qsca=`head -5 $infile |tail -1 | cut -c 1-18`
    qabs=`head -6 $infile |tail -1 | cut -c 1-18`
#    head -1 $infile | cut -c 6-18,25-37,41-53,61-73 > $outfile
    echo $suffx $cext $csca $cabs $qext $qsca $qabs >> $outfile
done

#----------------------------------
#  second orientation:
#----------------------------------
files=`ls C000002_??`
outfile=OP2
if [ -f $outfile ]; then
    rm $outfile
fi
touch $outfile


for infile in $files; do
    suffx=${infile:8}
    cext=`head -1 $infile |tail -1 | cut -c 1-18`
    csca=`head -2 $infile |tail -1 | cut -c 1-18`
    cabs=`head -3 $infile |tail -1 | cut -c 1-18`
    qext=`head -4 $infile |tail -1 | cut -c 1-18`
    qsca=`head -5 $infile |tail -1 | cut -c 1-18`
    qabs=`head -6 $infile |tail -1 | cut -c 1-18`
#    head -1 $infile | cut -c 6-18,25-37,41-53,61-73 > $outfile
    echo $suffx $cext $csca $cabs $qext $qsca $qabs >> $outfile
done

#=========================================================
#  Try to guess the Fortran compiler
#=========================================================
cd ..
if [ -x reciperr.x ]; then
    :
elif [ -x /usr/bin/gfortran ]; then
    /usr/bin/gfortran reciperr.f -o reciperr.x
elif [ -x /usr/bin/g77 ]; then
    /usr/bin/g77 reciperr.f -o reciperr.x
elif [ -x /usr/bin/ifort ]; then
    /usr/bin/ifort reciperr.f -o reciperr.x
else
    echo ERROR: Cannot find Fortran compiler
    echo Please compile the code reciperr.f by hand
    echo and call the executable reciperr.x
    exit
fi
exe=../reciperr.x
cd $base
#=========================================================
#  Compute reciprocity errors:
#=========================================================
files=`ls D000001_??`

for file in $files; do
    prefx=${file:0:6}
    suffx=${file:8}
    file2=${prefx}2_${suffx}
#----------------------------------
#  differential scattering cross
#  section, 1st orientation,
#  scattering angle=90 deg:
#----------------------------------
    head -721 $file | tail -1 | cut -c 17-30,65-82 > tmpfile
    head -2161 $file2 | tail -1 | cut -c 17-30,65-82 >> tmpfile

    errors=`$exe`
    echo $suffx $errors >> reciperr.dat

done
rm tmpfile