#!/bin/bash
#SBATCH -N 1 -n 1
#SBATCH -t 168:00:00

#=========================================================
#  Generate input files for different values of nmax:
#=========================================================
./mkinput.bash

#=========================================================
#  In- and output directory:
#=========================================================
cd ../..
in=EXAMPLES/Convergence_Test_Hexagonal_Prism/
out=EXAMPLES/Convergence_Test_Hexagonal_Prism/output
if [ -d $out ]; then
    :
else
    mkdir $out
fi

#=========================================================
#  Loop over all input files, run Tsym, and move output:
#=========================================================
cd $in
#files=`ls params_??`
files=`ls params_[0-9]? params_50`
cd -

for file in $files; do
    id=${file:7}

    cp ${in}/$file params
    ./tsym.x  > logfile
    mv C000001 ${out}/C000001_$id
    mv C000002 ${out}/C000002_$id
    mv D000001 ${out}/D000001_$id
    mv D000002 ${out}/D000002_$id
    mv F000001 ${out}/F000001_$id
    mv F000002 ${out}/F000002_$id
    mv F.dat ${out}/F_${id}
    mv E.dat ${out}/E_${id}
    if [ -f C.dat ]; then
	mv C.dat ${out}/C_${id}
    fi

done

#=========================================================
#  Post-processing of results:
#=========================================================
cd $in
./post_processing.bash
cd -
