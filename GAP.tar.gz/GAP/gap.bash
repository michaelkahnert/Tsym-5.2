#!/bin/bash

#-------------------------------------------------------
#  edit:
#
#  Possible choices for group: 
#     non-cubic groups:
#        Cn, Cnv, Cnh, Dnh, Dnd, Sn, (set Nsym >= 3)
#        Cs, Ci (Nsym not used)
#     cubic groups:
#        T, Td, O, Oh (Nsym not used)
#
groups="Cn"
Nsyms="16"
#
# Replace the following line with GAP path on your installation:
gap=/home/sm_mkahn/gap/gap4r4/bin/gap.sh
# 
#-------------------------------------------------------

mkin=./generate_gap_input.x
reorder=./reorder_character_table.x

for group in $groups; do
    for Nsym in $Nsyms; do

	echo $group $Nsym > gap.par	
	$mkin
	
	$gap -b < gap.in
	
	lines=`wc -l gap.out | cut -f1 -d" "`
	width=`wc -L gap.out | cut -f1 -d" "`
	order=`head -2 gap.out |tail -1` # currently not used
	
	l1=`expr $lines - 1`
	l2=`expr $lines - 2`
	l3=`expr $lines - 3`
	l4=`expr $lines - 4`
	
	head -$l1 gap.out | tail -$l4 > tmp
	
# echo $width > gap.out
# less tmp >> gap.out
	
	mv tmp gap.out
	
	$gap -b < gap2.in
	
	$reorder
	
	if [ $group == "Cn" ]; then
	    pref="C"
	    suff=""
	elif [ $group == "Cnh" ]; then
	    pref="C"
	    suff="h"
	elif [ $group == "Cnv" ]; then
	    pref="C"
	    suff="v"
	elif [ $group == "Dn" ]; then
	    pref="D"
	    suff=""
	elif [ $group == "Dnh" ]; then
	    pref="D"
	    suff="h"
	elif [ $group == "Dnd" ]; then
	    pref="D"
	    suff="d"
	elif [ $group == "Sn" ]; then
	    pref="S"
	    suff=""
	fi

	if [ $group == "T" -o $group == "Td" -o $group == "O" -o $group == "Oh" ]; then
	    outfile=${group}.char
	elif [ $Nsym -lt 10 ]; then
	    outfile=${pref}000${Nsym}${suff}.char
	elif [ $Nsym -lt 100 ]; then
	    outfile=${pref}00${Nsym}${suff}.char
	elif [ $Nsym -lt 1000 ]; then
	    outfile=${pref}0${Nsym}${suff}.char
	elif [ $Nsym -lt 10000 ]; then
	    outfile=${pref}${Nsym}${suff}.char
	else
	    outfile=out.char
	fi
	
	mv Tsym.char $outfile
    done
done
